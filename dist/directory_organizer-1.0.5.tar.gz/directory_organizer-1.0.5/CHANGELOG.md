Change Log
==========

1.0.0 (03/10/2020)
-------------------
- First Release (Initial)

1.0.2 (03/10/2020)
-------------------
- Second Release (Package)

1.0.3 (03/10/2020)
-------------------
- Third Release (DEBUG : Package)

1.0.4 (05/10/2020)
-------------------
- Fourth Release
* Added new File Extensions for Support.
* New File Extensions Class.
* Fixed Minor Bugs.

1.0.5 (06/10/2020)
-------------------
- Fifth Release
* Fixed Minor Bugs. (for PDFs and Documentation)